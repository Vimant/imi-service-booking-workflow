# IMI SERVICE LLC - QUICK SETUP CHECKLIST
## Get Your Booking System Running in 45 Minutes

---

## ☑️ STEP 1: Google Sheets Setup (15 min)

### Create New Sheet
- [ ] Go to sheets.google.com
- [ ] Create new spreadsheet
- [ ] Name: "IMI Service - Jobs & Invoices"

### Create 3 Tabs:

**Tab 1: "Bookings"**
- [ ] Add headers: Timestamp | Customer Name | Company Name | Email | Phone | Service Type | Job Description | Preferred Date | Address/Location | Additional Notes | Status

**Tab 2: "Time Tracking"**  
- [ ] Add headers: Job ID | Customer Name | Service Type | Date | Start Time | End Time | Break Time (min) | Total Hours | Hourly Rate | Labor Cost | Materials Cost | Notes
- [ ] In H2: `=IF(AND(E2<>"",F2<>""), (F2-E2)*24 - (G2/60), "")`
- [ ] In I2: `130`
- [ ] In J2: `=IF(H2<>"", H2*I2, "")`
- [ ] Format E&F as Time, H as Number, I/J/K as Currency
- [ ] Copy row 2 down to row 100

**Tab 3: "Invoice Generator"**
- [ ] Add headers: Invoice # | Date | Customer Name | Company | Email | Service Type | Hours Worked | Hourly Rate | Labor Cost | Materials | Total | Status
- [ ] In A2: `="INV-"&TEXT(ROW()-1,"0000")`
- [ ] In H2: `130`
- [ ] In I2: `=G2*H2`
- [ ] In K2: `=I2+J2`
- [ ] Format B as Date, G as Number, H/I/J/K as Currency
- [ ] Copy row 2 down to row 100

---

## ☑️ STEP 2: Google Apps Script Setup (15 min)

- [ ] In your sheet: Extensions > Apps Script
- [ ] Delete existing code
- [ ] Copy/paste code from `google-apps-script.js`
- [ ] Replace these in the code:
  - [ ] `[YOUR PHONE NUMBER]` → Your phone
  - [ ] `[YOUR EMAIL]` → Your email
  - [ ] `[Your Address]` → Your address
  - [ ] `[YOUR_ADMIN_EMAIL_HERE]` → Where you want notifications
- [ ] Click Deploy > New deployment
- [ ] Type: Web app
- [ ] Execute as: Me
- [ ] Access: Anyone
- [ ] Click Deploy > Authorize > Allow
- [ ] **COPY THE WEB APP URL** ← Important!

---

## ☑️ STEP 3: Web Form Setup (15 min)

- [ ] Open `booking-form.html` in text editor
- [ ] Find/replace:
  - [ ] `YOUR_GOOGLE_SCRIPT_URL_HERE` → Paste Web App URL from Step 2
  - [ ] `YOUR_FAQ_LINK_HERE` → Your FAQ link (if you have one)
  - [ ] `[YOUR PHONE NUMBER]` → Your phone (appears in multiple places)
  - [ ] `[YOUR EMAIL]` → Your email
  - [ ] `[Your Address Line 1]` → Address line 1
  - [ ] `[Your Address Line 2]` → Address line 2

### Host Your Form (Choose One):

**Option A: Add to Your Website**
- [ ] Upload `booking-form.html` to your web hosting
- [ ] Link to it from your main site

**Option B: GitHub Pages (Free)**
- [ ] Create GitHub account
- [ ] Create repository "imi-booking"
- [ ] Upload file as `index.html`
- [ ] Enable GitHub Pages in Settings
- [ ] Your URL: `https://[username].github.io/imi-booking`

**Option C: Google Sites**
- [ ] Create Google Site
- [ ] Add Embed component
- [ ] Paste entire HTML code
- [ ] Publish

---

## ☑️ STEP 4: Test Everything (5 min)

- [ ] Open your web form
- [ ] Select a service (should highlight)
- [ ] Fill in form with test data:
  - Name: Test User
  - Email: YOUR-EMAIL (so you get the emails)
  - Phone: 555-0123
  - Service: New Installation
  - Description: Test booking
  - Date: Tomorrow
  - Location: 123 Test St
- [ ] Submit form
- [ ] Check for success message
- [ ] Verify data appears in Bookings tab
- [ ] Check your email for 2 emails:
  - [ ] Customer confirmation
  - [ ] Admin notification
- [ ] Delete test entry from sheet

---

## ☑️ STEP 5: Go Live! (5 min)

- [ ] Share booking form URL with customers
- [ ] Add link to your website
- [ ] Add to email signature
- [ ] Post on social media
- [ ] Create QR code at qr-code-generator.com

---

## 📊 DAILY OPERATIONS

### When New Booking Arrives:
1. Check email notification
2. Review in Bookings tab
3. Contact customer to confirm
4. Inform: "Time tracked door-to-door. Weekly invoicing. Payment due in 10 days."
5. Update Status to "Scheduled"

### After Job Completion:
1. Technician fills Time Tracking tab (DOOR-TO-DOOR times)
2. Friday: Review all week's jobs
3. Create weekly invoice in Invoice Generator
4. Email invoice to customer
5. Track payment (due 10 days from invoice)

---

## 🆘 QUICK TROUBLESHOOTING

**Form doesn't submit:**
- Check Web App URL in HTML is correct
- Verify Apps Script is deployed as "Anyone" access

**No emails:**
- Run `testEmails()` function in Apps Script
- Check you replaced `[YOUR_ADMIN_EMAIL_HERE]`

**Formulas broken:**
- Don't delete row 2
- Format time columns as TIME
- Format currency columns as CURRENCY

---

## ✅ YOU'RE DONE!

Your professional booking system is now:
- ✓ Accepting bookings 24/7
- ✓ Automatically sending emails
- ✓ Tracking time and calculating costs
- ✓ Generating professional invoices

**Form URL:** _________________
**Sheet Link:** _________________

---

## 📞 QUICK REFERENCE

**Hourly Rate:** $130/hour
**Time Tracking:** Door-to-Door (shop to shop, includes travel)
**Invoicing:** Weekly (every Friday)
**Payment Terms:** Net 10 Days from invoice date

**Services Offered:**
- New Installation
- Deinstallation
- Quality Control
- AI Automation

**Response Time:** Within 24 hours
**Payment Terms:** Net 10 Days from invoice date

**Time Tracking Method:**
- Door-to-door (leave shop → return to shop)
- Includes all travel time
- Deduct only unpaid breaks

---

**Setup Date:** __________
**Completed By:** __________
**Status:** □ Testing  □ Live

---

IMI SERVICE LLC - Industrial Maintenance Excellence

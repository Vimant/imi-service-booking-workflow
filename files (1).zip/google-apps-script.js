// IMI SERVICE LLC - Google Apps Script
// This script receives booking data from your web form and saves it to Google Sheets

// SETUP INSTRUCTIONS:
// 1. Open your Google Sheet "IMI Service - Jobs & Invoices"
// 2. Go to Extensions > Apps Script
// 3. Delete any existing code
// 4. Paste this entire script
// 5. Click "Deploy" > "New deployment"
// 6. Choose type: "Web app"
// 7. Execute as: "Me"
// 8. Who has access: "Anyone"
// 9. Click "Deploy" and copy the Web App URL
// 10. Paste that URL in the booking-form.html file where it says YOUR_GOOGLE_SCRIPT_URL_HERE

// Main function to handle POST requests from the web form
function doPost(e) {
  try {
    // Parse the incoming JSON data
    const data = JSON.parse(e.postData.contents);
    
    // Get the active spreadsheet
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    
    // Get or create the Bookings sheet
    let sheet = ss.getSheetByName('Bookings');
    if (!sheet) {
      sheet = ss.insertSheet('Bookings');
      // Add headers if new sheet
      sheet.appendRow([
        'Timestamp', 
        'Customer Name', 
        'Company Name', 
        'Email', 
        'Phone', 
        'Service Type', 
        'Job Description', 
        'Preferred Date', 
        'Address/Location', 
        'Additional Notes',
        'Status'
      ]);
    }
    
    // Append the booking data
    sheet.appendRow([
      new Date(data.timestamp),
      data.customerName,
      data.companyName || '',
      data.email,
      data.phone,
      data.service,
      data.jobDescription,
      data.preferredDate,
      data.location,
      data.additionalNotes || '',
      data.status
    ]);
    
    // Send confirmation email to customer
    sendCustomerConfirmation(data);
    
    // Send notification email to you
    sendAdminNotification(data);
    
    // Return success response
    return ContentService.createTextOutput(JSON.stringify({
      status: 'success',
      message: 'Booking received'
    })).setMimeType(ContentService.MimeType.JSON);
    
  } catch (error) {
    // Log error and return error response
    Logger.log('Error: ' + error.toString());
    return ContentService.createTextOutput(JSON.stringify({
      status: 'error',
      message: error.toString()
    })).setMimeType(ContentService.MimeType.JSON);
  }
}

// Send confirmation email to customer
function sendCustomerConfirmation(data) {
  const subject = 'Service Request Received - IMI Service LLC';
  
  const htmlBody = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <div style="background: linear-gradient(135deg, #FFD700, #FF8C00); padding: 30px; text-align: center;">
        <h1 style="color: #0a0a0a; margin: 0; font-size: 2.5rem; letter-spacing: 3px;">IMI SERVICE LLC</h1>
        <p style="color: #0a0a0a; margin: 5px 0 0 0; letter-spacing: 1px;">Industrial Maintenance Excellence</p>
      </div>
      
      <div style="background: #ffffff; padding: 40px;">
        <h2 style="color: #0a0a0a; margin-top: 0;">Thank You for Your Service Request!</h2>
        
        <p style="color: #333333; line-height: 1.6;">
          We've received your booking request and will contact you within 24 hours to confirm your appointment and provide a detailed quote.
        </p>
        
        <div style="background: #f5f5f5; border-left: 4px solid #FFD700; padding: 20px; margin: 30px 0;">
          <h3 style="color: #0a0a0a; margin-top: 0;">Your Booking Details:</h3>
          <table style="width: 100%; border-collapse: collapse;">
            <tr>
              <td style="padding: 8px 0; color: #666; font-weight: 600;">Service:</td>
              <td style="padding: 8px 0; color: #0a0a0a;">${data.service}</td>
            </tr>
            <tr>
              <td style="padding: 8px 0; color: #666; font-weight: 600;">Preferred Date:</td>
              <td style="padding: 8px 0; color: #0a0a0a;">${data.preferredDate}</td>
            </tr>
            <tr>
              <td style="padding: 8px 0; color: #666; font-weight: 600;">Location:</td>
              <td style="padding: 8px 0; color: #0a0a0a;">${data.location}</td>
            </tr>
            <tr>
              <td style="padding: 8px 0; color: #666; font-weight: 600;">Hourly Rate:</td>
              <td style="padding: 8px 0; color: #0a0a0a;">$130/hour</td>
            </tr>
          </table>
        </div>
        
        <p style="color: #333333; line-height: 1.6;">
          <strong>What happens next?</strong><br>
          1. Our team will review your request<br>
          2. We'll contact you to confirm the appointment<br>
          3. We'll provide a detailed quote based on your requirements<br>
          4. Once confirmed, our certified technician will arrive on the scheduled date
        </p>
        
        <div style="background: #f0f0f0; padding: 15px; margin: 20px 0; border-left: 3px solid #FFD700;">
          <p style="margin: 0; color: #333;">
            <strong>Important Billing Information:</strong><br>
            • Time is tracked door-to-door (from when we leave to when we return)<br>
            • Invoices are sent weekly<br>
            • Payment is due within 10 days of invoice date
          </p>
        </div>
        
        <div style="background: #FFD700; padding: 20px; margin: 30px 0; text-align: center;">
          <p style="margin: 0; color: #0a0a0a; font-size: 1.1rem;">
            <strong>Need to reach us sooner?</strong><br>
            Call: <span style="font-size: 1.2rem;">[YOUR PHONE NUMBER]</span><br>
            Email: <span>[YOUR EMAIL]</span>
          </p>
        </div>
        
        <p style="color: #666; font-size: 0.9rem; margin-top: 40px;">
          If you have any questions, please don't hesitate to contact us.
        </p>
      </div>
      
      <div style="background: #0a0a0a; color: #b0b0b0; padding: 20px; text-align: center; font-size: 0.9rem;">
        <p style="margin: 0;">IMI Service LLC - Industrial Maintenance Services</p>
        <p style="margin: 5px 0;">[Your Address] | [Your Phone] | [Your Email]</p>
      </div>
    </div>
  `;
  
  const plainBody = `
IMI SERVICE LLC - Service Request Confirmation

Thank you for choosing IMI Service LLC!

We've received your booking request and will contact you within 24 hours to confirm your appointment.

YOUR BOOKING DETAILS:
Service: ${data.service}
Preferred Date: ${data.preferredDate}
Location: ${data.location}
Hourly Rate: $130/hour

WHAT HAPPENS NEXT:
1. Our team will review your request
2. We'll contact you to confirm the appointment
3. We'll provide a detailed quote
4. Our certified technician will arrive on the scheduled date

IMPORTANT BILLING INFORMATION:
• Time is tracked door-to-door (from when we leave to when we return)
• Invoices are sent weekly
• Payment is due within 10 days of invoice date

Questions? Contact us:
Phone: [YOUR PHONE NUMBER]
Email: [YOUR EMAIL]

Thank you for choosing IMI Service LLC!
  `;
  
  try {
    MailApp.sendEmail({
      to: data.email,
      subject: subject,
      body: plainBody,
      htmlBody: htmlBody,
      name: 'IMI Service LLC'
    });
  } catch (error) {
    Logger.log('Error sending customer email: ' + error.toString());
  }
}

// Send notification email to admin
function sendAdminNotification(data) {
  const adminEmail = '[YOUR_ADMIN_EMAIL_HERE]'; // CHANGE THIS to your email
  const subject = `🔔 New Service Booking: ${data.service}`;
  
  const htmlBody = `
    <div style="font-family: Arial, sans-serif; max-width: 600px;">
      <h2 style="color: #FFD700;">New Service Booking Received</h2>
      
      <div style="background: #f5f5f5; padding: 20px; border-left: 4px solid #FFD700;">
        <h3 style="margin-top: 0;">Customer Information:</h3>
        <p><strong>Name:</strong> ${data.customerName}</p>
        <p><strong>Company:</strong> ${data.companyName || 'N/A'}</p>
        <p><strong>Email:</strong> ${data.email}</p>
        <p><strong>Phone:</strong> ${data.phone}</p>
      </div>
      
      <div style="background: #ffffff; padding: 20px; margin-top: 20px; border: 1px solid #ddd;">
        <h3 style="margin-top: 0;">Job Details:</h3>
        <p><strong>Service Type:</strong> ${data.service}</p>
        <p><strong>Preferred Date:</strong> ${data.preferredDate}</p>
        <p><strong>Location:</strong> ${data.location}</p>
        <p><strong>Description:</strong><br>${data.jobDescription}</p>
        ${data.additionalNotes ? `<p><strong>Additional Notes:</strong><br>${data.additionalNotes}</p>` : ''}
      </div>
      
      <div style="background: #FFD700; padding: 15px; margin-top: 20px; text-align: center;">
        <p style="margin: 0; color: #0a0a0a;"><strong>⚡ Action Required:</strong> Contact customer within 24 hours to confirm booking</p>
      </div>
      
      <p style="color: #666; font-size: 0.9rem; margin-top: 20px;">
        This booking has been automatically added to your Google Sheet.
      </p>
    </div>
  `;
  
  const plainBody = `
NEW SERVICE BOOKING RECEIVED

CUSTOMER INFORMATION:
Name: ${data.customerName}
Company: ${data.companyName || 'N/A'}
Email: ${data.email}
Phone: ${data.phone}

JOB DETAILS:
Service Type: ${data.service}
Preferred Date: ${data.preferredDate}
Location: ${data.location}
Description: ${data.jobDescription}
${data.additionalNotes ? `Additional Notes: ${data.additionalNotes}` : ''}

ACTION REQUIRED: Contact customer within 24 hours to confirm booking.

This booking has been automatically added to your Google Sheet.
  `;
  
  try {
    MailApp.sendEmail({
      to: adminEmail,
      subject: subject,
      body: plainBody,
      htmlBody: htmlBody
    });
  } catch (error) {
    Logger.log('Error sending admin email: ' + error.toString());
  }
}

// Test function - you can run this to test the email templates
function testEmails() {
  const testData = {
    timestamp: new Date().toISOString(),
    customerName: 'John Doe',
    companyName: 'Test Industries',
    email: 'test@example.com',
    phone: '555-0123',
    service: 'New Installation',
    jobDescription: 'Need to install new conveyor system',
    preferredDate: '2026-02-15',
    location: '123 Industrial Park, City, ST 12345',
    additionalNotes: 'Access code: 1234',
    status: 'Pending'
  };
  
  sendCustomerConfirmation(testData);
  sendAdminNotification(testData);
  
  Logger.log('Test emails sent!');
}

// Function to handle GET requests (optional - for testing)
function doGet() {
  return ContentService.createTextOutput('IMI Service LLC Booking System is running!');
}

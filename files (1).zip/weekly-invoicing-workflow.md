# IMI SERVICE LLC - WEEKLY INVOICING WORKFLOW

## Important Billing Policies

### Time Tracking: Door-to-Door
**What "Door-to-Door" Means:**
- Time starts when technician leaves the office/shop
- Time includes all travel to job site
- Time includes all work performed on site
- Time includes all travel back to office/shop
- Time ends when technician returns to office/shop

**Example:**
- Technician leaves shop: 8:00 AM
- Arrives at customer site: 9:00 AM
- Works on site: 9:00 AM - 3:00 PM
- Returns to shop: 4:00 PM
- **BILLABLE TIME: 8:00 AM to 4:00 PM = 8 hours** (minus breaks)

### Payment Terms
- Invoices are sent **weekly** (every Friday)
- Payment due **within 10 days** of invoice date
- Example: Invoice dated Friday Feb 7 → Due Monday Feb 17

---

## WEEKLY INVOICING SCHEDULE

### Every Friday Afternoon

**Step 1: Review Completed Jobs (10 minutes)**
1. Open Google Sheet > Time Tracking tab
2. Review all jobs completed this week (Monday-Friday)
3. Verify all time entries are complete and accurate
4. Confirm break times are recorded
5. Check that materials costs are entered

**Step 2: Generate Weekly Invoices (20 minutes)**

For EACH customer who had work done this week:

1. Go to Invoice Generator tab
2. Find next empty row
3. Fill in invoice details:
   - **Invoice #**: Auto-generates (INV-0001, INV-0002, etc.)
   - **Date**: Today's date (the Friday)
   - **Customer Name**: From Time Tracking
   - **Company**: From Bookings tab
   - **Email**: From Bookings tab
   - **Service Type**: From Time Tracking (if multiple jobs, list as "Multiple Services")
   - **Hours Worked**: SUM of all hours for this customer this week
   - **Hourly Rate**: 130 (pre-filled)
   - **Labor Cost**: Auto-calculates
   - **Materials**: SUM of all materials for this customer this week
   - **Total**: Auto-calculates
   - **Status**: "Pending"

**Step 3: Calculate Due Date**
- Invoice Date + 10 days = Due Date
- Add a "Due Date" column if needed (Column M)
- Formula: `=B2+10` (where B2 is the invoice date)

**Step 4: Send Invoices via Email (30 minutes)**

For each invoice, send this email:

---

**Subject:** Invoice [INV-####] - IMI Service LLC - Due [Date]

**Body:**
```
Dear [Customer Name],

Please find your weekly invoice from IMI Service LLC for services rendered during [Date Range].

═══════════════════════════════════════════════════
INVOICE DETAILS
═══════════════════════════════════════════════════

Invoice Number: INV-[NUMBER]
Invoice Date: [DATE]
Due Date: [DUE DATE - 10 days from invoice date]

BILL TO:
[Customer Name]
[Company Name]
[Address]

═══════════════════════════════════════════════════
SERVICES PROVIDED - WEEK OF [DATE RANGE]
═══════════════════════════════════════════════════

[List each job completed this week:]

Job 1: [Date] - [Service Type] at [Location]
  Door-to-Door Time: [Start Time] to [End Time]
  Hours: [X.XX hours]

Job 2: [Date] - [Service Type] at [Location]
  Door-to-Door Time: [Start Time] to [End Time]
  Hours: [X.XX hours]

Total Hours This Week: [X.XX hours]

═══════════════════════════════════════════════════
CHARGES
═══════════════════════════════════════════════════

Labor: [Total Hours] hours @ $130/hour        $[Labor Cost]

Materials & Supplies:                          $[Materials]

                                    TOTAL DUE: $[Total Amount]

═══════════════════════════════════════════════════
PAYMENT INFORMATION
═══════════════════════════════════════════════════

Payment Terms: Net 10 Days
Due Date: [DUE DATE]

IMPORTANT: Time is tracked door-to-door (from our facility to your 
location and back). This includes all travel time.

Accepted Payment Methods:
[Your payment methods - check, ACH, credit card, etc.]

Payment Instructions:
[Your payment details]

═══════════════════════════════════════════════════

Questions about this invoice? Contact us:
Phone: [Your Phone]
Email: [Your Email]

Thank you for choosing IMI Service LLC!

═══════════════════════════════════════════════════
IMI SERVICE LLC
Industrial Maintenance Excellence
[Your Address]
[Your Phone] | [Your Email]
```

---

**Step 5: Update Invoice Status**
- After sending each invoice, update Status column to "Sent"
- Record the email sent date (optional: add "Date Sent" column)

**Step 6: Set Payment Reminders**
- Create calendar reminders for 10 days from each invoice
- Check on due date if payment has been received

---

## TRACKING DOOR-TO-DOOR TIME

### For Office Staff (Scheduling)
When scheduling jobs, inform customers:
> "Please note: Our time tracking is door-to-door, meaning billing starts when 
> our technician leaves our facility and ends when they return. This includes 
> travel time to and from your location."

### For Technicians (Time Tracking)

**What to Record:**

In the Time Tracking sheet:
- **Start Time**: When you LEAVE the shop/office
- **End Time**: When you RETURN to the shop/office
- **Break Time**: Any unpaid breaks (lunch, etc.)

**Example Time Sheet Entry:**

| Start Time | End Time | Break Time | Total Hours | Notes |
|------------|----------|------------|-------------|-------|
| 8:00 AM | 4:00 PM | 30 min | 7.5 hours | Left shop 8am, arrived site 9am, worked until 3pm, returned to shop 4pm |

**Important:**
- DO record actual departure and return times
- DO deduct legitimate break times
- DO add notes about drive time if significant
- DON'T estimate - use actual times
- DON'T include breaks you worked through

### Example Scenarios

**Scenario 1: Single Job, Close Location**
- Leave shop: 8:00 AM
- Drive: 15 minutes
- Work on site: 8:15 AM - 12:00 PM
- Lunch break: 30 minutes (unpaid)
- Work on site: 12:30 PM - 3:30 PM
- Drive back: 15 minutes
- Return to shop: 3:45 PM

**Time Entry:**
- Start: 8:00 AM
- End: 3:45 PM
- Break: 30 minutes
- **Billable: 7.25 hours**

**Scenario 2: Multiple Jobs, Same Day**
- Leave shop: 7:00 AM
- Job 1: 7:30 AM - 10:30 AM
- Drive to Job 2: 20 minutes
- Job 2: 10:50 AM - 2:00 PM
- Lunch: 30 minutes (unpaid)
- Job 2 continues: 2:30 PM - 4:00 PM
- Return to shop: 4:45 PM

**Time Entry:**
- Start: 7:00 AM
- End: 4:45 PM
- Break: 30 minutes
- **Billable: 9.25 hours**
- **Notes**: Two jobs - Customer A (Job 1) and Customer B (Job 2)

**Scenario 3: Remote Location**
- Leave shop: 6:00 AM
- Drive: 2 hours
- Work on site: 8:00 AM - 4:00 PM (1 hour lunch)
- Drive back: 2 hours
- Return to shop: 6:00 PM

**Time Entry:**
- Start: 6:00 AM
- End: 6:00 PM
- Break: 60 minutes
- **Billable: 11 hours**
- **Notes**: Remote job, 2-hour drive each way

---

## PAYMENT TRACKING

### When Payment is Received

1. Go to Invoice Generator tab
2. Find the invoice row
3. Update Status from "Sent" to "Paid"
4. Optional: Add "Payment Date" column and record date received
5. Optional: Add "Payment Method" column (Check, ACH, Card, etc.)

### When Payment is Overdue (After 10 Days)

**Day 11 - Send Friendly Reminder:**

```
Subject: Payment Reminder - Invoice [INV-####] Now Due

Dear [Customer Name],

This is a friendly reminder that invoice [INV-####] for $[Amount] 
was due on [Due Date].

If you've already sent payment, please disregard this notice. 
Otherwise, please submit payment at your earliest convenience.

Invoice Details:
- Invoice #: [INV-####]
- Original Date: [Invoice Date]
- Due Date: [Due Date]
- Amount: $[Total]

If you have any questions or need to arrange a payment plan, 
please contact us.

Thank you,
IMI Service LLC
[Phone] | [Email]
```

**Day 20 - Second Reminder:**

```
Subject: OVERDUE - Invoice [INV-####] Payment Required

Dear [Customer Name],

Invoice [INV-####] for $[Amount] is now 10 days overdue (original 
due date: [Due Date]).

Please remit payment immediately to avoid any service interruptions 
or late fees.

If there's an issue with the invoice, please contact us right away 
so we can resolve it.

Amount Due: $[Total]
Days Overdue: [X days]

Thank you,
IMI Service LLC
[Phone] | [Email]
```

**Day 30+ - Escalate:**
- Phone call to customer
- Consider pausing additional services
- Discuss payment plan options
- Consider collection agency (if company policy)

---

## WEEKLY INVOICING CHECKLIST

**Every Monday Morning:**
- [ ] Review last week's invoices
- [ ] Check for any payments received over weekend
- [ ] Update payment statuses

**Every Wednesday:**
- [ ] Follow up on any invoices from 2 weeks ago
- [ ] Send reminder emails if needed

**Every Friday:**
- [ ] Review all Time Tracking entries for the week
- [ ] Verify all entries are complete
- [ ] Generate invoices for the week
- [ ] Send all invoices before 5 PM
- [ ] Update all statuses to "Sent"
- [ ] Set calendar reminders for due dates (10 days out)

---

## MONTHLY REPORTING (Optional)

At end of each month, create summary report:

**Revenue Summary:**
- Total invoices sent this month
- Total amount invoiced
- Total payments received
- Outstanding receivables
- Average invoice amount
- Average payment time

**Customer Analysis:**
- Top customers by revenue
- Number of jobs per customer
- Average hours per customer

**Service Breakdown:**
- Hours by service type
- Revenue by service type
- Most common services

---

## TIPS FOR SUCCESSFUL WEEKLY INVOICING

### For Accuracy:
✓ Have technicians fill time sheets SAME DAY
✓ Review time entries every evening
✓ Keep detailed notes about travel times
✓ Photograph odometers for long drives (backup documentation)

### For Prompt Payment:
✓ Send invoices consistently every Friday
✓ Make payment instructions crystal clear
✓ Offer multiple payment methods
✓ Follow up promptly on overdue accounts
✓ Build good relationships with clients

### For Documentation:
✓ Keep copies of all invoices sent
✓ Save all payment confirmation emails
✓ Document all phone conversations about payments
✓ Maintain organized records for tax time

---

## PAYMENT TERMS SUMMARY

| Item | Details |
|------|---------|
| Billing Cycle | Weekly (every Friday) |
| Payment Terms | Net 10 Days |
| Time Tracking | Door-to-Door |
| Late Fees | [Your policy] |
| Accepted Payments | [Your methods] |
| Early Payment Discount | [If applicable] |

---

## SAMPLE WEEKLY INVOICE CALCULATION

**Customer: ABC Manufacturing**
**Week of: Feb 3-7, 2026**

**Monday Feb 3:**
- New Installation at Building A
- Left shop: 7:30 AM, Returned: 4:00 PM
- Break: 30 min
- Hours: 8.0

**Wednesday Feb 5:**
- Quality Control at Building B  
- Left shop: 8:00 AM, Returned: 12:30 PM
- Break: 0 min
- Hours: 4.5

**Friday Feb 7:**
- AI Automation setup at Building A
- Left shop: 1:00 PM, Returned: 5:30 PM
- Break: 0 min
- Hours: 4.5

**Materials:**
- Sensors: $250
- Cables: $75
- **Total Materials: $325**

**WEEKLY INVOICE:**
- Total Hours: 17.0 hours
- Labor (17 × $130): $2,210
- Materials: $325
- **TOTAL DUE: $2,535**
- **Due Date: Feb 17, 2026**

---

**System Updated:** February 2026
**For:** IMI SERVICE LLC
**Billing:** Weekly, Net 10 Days, Door-to-Door Time Tracking

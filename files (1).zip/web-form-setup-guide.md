# IMI SERVICE LLC - Web Form + Google Sheets Setup Guide

## Complete System Overview

This system includes:
1. **Professional Web Booking Form** - Custom HTML form hosted on your website
2. **Google Apps Script** - Backend to receive form data
3. **Google Sheets Backend** - Automated tracking, time tracking, and invoicing
4. **Automatic Email Notifications** - To both customer and admin

---

## 🚀 QUICK START (Total Setup Time: 45 minutes)

### PHASE 1: Set Up Google Sheets (15 minutes)

#### Step 1: Create Your Master Sheet
1. Go to Google Sheets (sheets.google.com)
2. Create a new spreadsheet
3. Name it: **IMI Service - Jobs & Invoices**

#### Step 2: Create the Tabs

**TAB 1: Bookings**
1. Rename "Sheet1" to "Bookings"
2. Add these headers in Row 1:

| A | B | C | D | E | F | G | H | I | J | K |
|---|---|---|---|---|---|---|---|---|---|---|
| Timestamp | Customer Name | Company Name | Email | Phone | Service Type | Job Description | Preferred Date | Address/Location | Additional Notes | Status |

**TAB 2: Time Tracking**
1. Create new tab named "Time Tracking"
2. Add these headers in Row 1:

| A | B | C | D | E | F | G | H | I | J | K | L |
|---|---|---|---|---|---|---|---|---|---|---|---|
| Job ID | Customer Name | Service Type | Date | Start Time | End Time | Break Time (min) | Total Hours | Hourly Rate | Labor Cost | Materials Cost | Notes |

3. In Row 2, enter these formulas:
   - A2: `001` (manually number your jobs)
   - H2: `=IF(AND(E2<>"",F2<>""), (F2-E2)*24 - (G2/60), "")`
   - I2: `130`
   - J2: `=IF(H2<>"", H2*I2, "")`

4. Format columns:
   - E & F: Format > Number > Time
   - H: Format > Number > Number (2 decimals)
   - I, J, K: Format > Number > Currency

5. Copy row 2 down to row 100 for future jobs

**TAB 3: Invoice Generator**
1. Create new tab named "Invoice Generator"
2. Add these headers in Row 1:

| A | B | C | D | E | F | G | H | I | J | K | L |
|---|---|---|---|---|---|---|---|---|---|---|---|
| Invoice # | Date | Customer Name | Company | Email | Service Type | Hours Worked | Hourly Rate | Labor Cost | Materials | Total | Status |

3. In Row 2, enter these formulas:
   - A2: `="INV-"&TEXT(ROW()-1,"0000")`
   - H2: `130`
   - I2: `=G2*H2`
   - K2: `=I2+J2`

4. Format columns:
   - B: Format > Number > Date
   - G: Format > Number > Number (2 decimals)
   - H, I, J, K: Format > Number > Currency

5. Copy row 2 down to row 100

**TAB 4: FAQ (Optional)**
1. Create new tab named "FAQ"
2. Use the template from the previous documents
3. Share this tab: Click "Share" > Change to "Anyone with the link can view"
4. Copy the shareable link

---

### PHASE 2: Set Up Google Apps Script (15 minutes)

#### Step 1: Open Apps Script
1. In your Google Sheet, go to **Extensions > Apps Script**
2. Delete any existing code in the editor

#### Step 2: Add the Script
1. Copy the entire content from `google-apps-script.js`
2. Paste it into the Apps Script editor

#### Step 3: Customize the Script
Find and replace these placeholders:
- `[YOUR PHONE NUMBER]` → Your actual phone
- `[YOUR EMAIL]` → Your business email
- `[Your Address]` → Your business address
- `[YOUR_ADMIN_EMAIL_HERE]` → Email where you want booking notifications

#### Step 4: Deploy as Web App
1. Click **Deploy > New deployment**
2. Click the gear icon ⚙️ next to "Select type"
3. Choose **Web app**
4. Fill in:
   - **Description:** IMI Booking System
   - **Execute as:** Me
   - **Who has access:** Anyone
5. Click **Deploy**
6. Click **Authorize access**
7. Choose your Google account
8. Click **Advanced** > **Go to [Your Project]**
9. Click **Allow**
10. **COPY THE WEB APP URL** - you'll need this next!

Example URL: `https://script.google.com/macros/s/ABC123.../exec`

---

### PHASE 3: Set Up Web Form (15 minutes)

#### Step 1: Customize the HTML Form
1. Open `booking-form.html` in a text editor
2. Find and replace:
   - `YOUR_FAQ_LINK_HERE` → Paste your FAQ sheet link (from Phase 1, Tab 4)
   - `YOUR_GOOGLE_SCRIPT_URL_HERE` → Paste the Web App URL you just copied

#### Step 2: Add Your Company Contact Info
Search for these placeholders and replace them:
- `[YOUR PHONE NUMBER]` → Your phone
- `[YOUR EMAIL]` → Your email
- `[Your Address Line 1]` → Address line 1
- `[Your Address Line 2]` → Address line 2
- `[Your Website]` → Your website

#### Step 3: Host the Form
You have several options:

**Option A: Add to Existing Website**
- Copy the HTML file to your website's hosting
- Upload via FTP, cPanel, or your hosting control panel
- Link to it from your main website

**Option B: Use Free Hosting (GitHub Pages)**
1. Go to github.com and create account
2. Create new repository named "imi-booking"
3. Upload `booking-form.html`
4. Rename it to `index.html`
5. Go to Settings > Pages
6. Select main branch > Save
7. Your form will be at: `https://[username].github.io/imi-booking`

**Option C: Google Sites**
1. Create a new Google Site
2. Add an "Embed" component
3. Click "Embed code"
4. Paste the entire HTML code
5. Publish your site

**Option D: Use the HTML directly**
- Email the file to customers
- They can open it in their browser
- It will still submit to your Google Sheet

---

## 📧 EMAIL NOTIFICATION SETUP

The system automatically sends TWO emails when a booking is submitted:

### Email 1: To Customer
- Confirms receipt of booking
- Shows booking details
- Provides your contact information
- Professional branded template

### Email 2: To You (Admin)
- New booking notification
- Complete customer and job details
- Reminder to contact customer within 24 hours
- Direct link to Google Sheet

Both emails are sent automatically by the Google Apps Script!

---

## 🔧 TESTING YOUR SYSTEM

### Test Checklist:
1. Open your web form in a browser
2. Select a service (card should highlight)
3. Fill in all required fields
4. Click "Request Service"
5. Verify:
   - ✓ Success message appears
   - ✓ Data appears in "Bookings" tab of Google Sheet
   - ✓ Customer receives confirmation email
   - ✓ You receive admin notification email

**Test Data Example:**
- Name: Test User
- Email: your-email@gmail.com (use your email for testing)
- Phone: 555-0123
- Service: New Installation
- Description: Test booking
- Date: [Tomorrow's date]
- Location: 123 Test St

After successful test, delete the test entry from your sheet.

---

## 📊 DAILY WORKFLOW

### For Admin/Office Staff:

**Morning (5 minutes):**
1. Check email for new booking notifications
2. Open Google Sheet > Bookings tab
3. Review any rows with Status = "Pending"
4. Contact customer to confirm (email or phone)
5. Inform them: "Time is tracked door-to-door from our facility. Invoices are sent weekly with 10-day payment terms."
6. Update Status to "Scheduled"

**After Confirming:**
Send confirmation email to customer:
```
Subject: Appointment Confirmed - IMI Service LLC

Dear [Name],

Your service appointment is confirmed!

Service: [Service Type]
Date: [Confirmed Date]
Time: [Arrival Time]
Location: [Address]
Technician: [Name]
Rate: $130/hour

Our technician will contact you 30 minutes before arrival.

Thank you,
IMI Service LLC
```

### For Technicians:

**IMPORTANT - Door-to-Door Time Tracking:**
Time starts when you LEAVE the shop/office and ends when you RETURN.
This includes all travel time to and from the job site.

**After Completing Job:**
1. Open Google Sheet > Time Tracking tab
2. Find next available row
3. Fill in:
   - Job ID (next sequential number)
   - Customer Name
   - Service Type
   - Date
   - **Start Time**: When you LEFT the shop (e.g., 8:00 AM)
   - **End Time**: When you RETURNED to shop (e.g., 4:30 PM)
   - **Break Time in minutes**: Unpaid breaks only (e.g., 30 for lunch)
   - Materials Cost (if applicable)
   - **Notes**: Include drive time if significant (e.g., "2-hour drive each way")
4. Total Hours and Labor Cost calculate automatically
5. Notify office that timesheet is complete

### For Invoicing:

**WEEKLY INVOICING SCHEDULE (Every Friday):**

**Step 1: Review Week's Work**
1. Open Google Sheet > Time Tracking tab
2. Review all jobs completed this week (Monday-Friday)
3. Verify all time entries are complete

**Step 2: Create Weekly Invoices**
For each customer who had work this week:

1. Go to Invoice Generator tab
2. Find next empty row
3. Fill in:
   - Invoice # auto-generates
   - Date (today - Friday)
   - Customer Name (from Bookings)
   - Company (from Bookings)
   - Email (from Bookings)
   - Service Type (from Time Tracking)
   - **Hours Worked**: SUM of ALL hours for this customer THIS WEEK
   - **Materials**: SUM of ALL materials for this customer THIS WEEK
4. Labor Cost and Total auto-calculate
5. Add Due Date column (optional): Invoice Date + 10 days
6. Set Status to "Pending"

**Step 3: Send Weekly Invoice**
Email template:

```
Subject: Weekly Invoice INV-[NUMBER] - Due [Date + 10 days]

Dear [Customer Name],

Please find your weekly invoice for services provided during [Date Range].

INVOICE DETAILS:
Invoice Number: INV-[NUMBER]
Invoice Date: [DATE]
Due Date: [DATE + 10 DAYS]

SERVICES THIS WEEK:
[List each job with date and hours]

CHARGES:
Labor: [TOTAL HOURS] hours @ $130/hour = $[LABOR]
Materials: $[MATERIALS]
TOTAL DUE: $[TOTAL]

PAYMENT TERMS: Net 10 Days
Time tracked door-to-door (includes travel time)

[Payment instructions]

Questions? Contact us at [PHONE] or [EMAIL]

Thank you,
IMI Service LLC
```

4. Update Status to "Sent"
5. Set calendar reminder for due date (10 days from invoice)

**Step 4: Track Payments**
- When payment received: Update Status to "Paid"
- Day 11 (if overdue): Send friendly reminder
- Day 20 (still overdue): Send urgent reminder
- Day 30+: Phone call, consider service suspension

---

## 🎨 CUSTOMIZING YOUR WEB FORM

### Change Colors:
In the `booking-form.html` file, find the `:root` section at the top of the `<style>` tag:

```css
:root {
    --industrial-black: #0a0a0a;      /* Main background */
    --industrial-gray: #1a1a1a;       /* Card backgrounds */
    --safety-yellow: #FFD700;         /* Primary accent */
    --warning-orange: #FF8C00;        /* Secondary accent */
}
```

### Add Your Logo:
1. Upload your logo image to your web hosting
2. In the HTML, replace this section:
```html
<h1 class="logo">IMI SERVICE LLC</h1>
```
with:
```html
<img src="your-logo.png" alt="IMI Service LLC" style="max-width: 300px;">
```

### Add More Services:
Copy this block and add it to the services grid:
```html
<div class="service-card" data-service="Your New Service">
    <div class="service-icon">🔌</div>
    <div class="service-name">Your New Service</div>
    <div class="service-rate">$130/hour</div>
</div>
```

---

## 🆘 TROUBLESHOOTING

### Problem: Form submits but data doesn't appear in Sheet
**Solution:**
1. Check that the Web App URL in HTML matches your deployed script
2. Verify the script has permission to access your sheet
3. Check Apps Script logs: Extensions > Apps Script > Executions

### Problem: Emails not sending
**Solution:**
1. Open Apps Script
2. Run the `testEmails()` function
3. Check if emails arrive
4. Make sure you replaced `[YOUR_ADMIN_EMAIL_HERE]` in the script
5. Verify Gmail quota hasn't been exceeded (100 emails/day limit)

### Problem: Form shows "There was an error"
**Solution:**
1. Open browser console (F12) to see error details
2. Verify Web App is deployed as "Anyone" has access
3. Re-deploy the Web App and update URL in HTML

### Problem: Formulas showing #ERROR
**Solution:**
- Start Time and End Time must be formatted as TIME
- Break Time must be a number (in minutes)
- Don't delete row 2 (template row)

### Problem: Invoice numbers not generating
**Solution:**
- Don't modify the formula in column A
- Make sure you're copying the row with formulas, not creating new blank rows

---

## 🔒 SECURITY & PRIVACY

### Data Protection:
- All data stored in your private Google Sheet
- Only you can access the sheet
- Google Apps Script runs under your account
- Web form uses HTTPS encryption

### Email Privacy:
- Customer emails are never shared
- Confirmation emails come from your Gmail
- No third-party services involved

### Backup Recommendations:
1. Enable version history: File > Version history
2. Download monthly backups: File > Download > Excel
3. Consider Google Sheets automatic backup (paid Google Workspace feature)

---

## 📈 ADVANCED FEATURES (Optional)

### Add Google Calendar Integration:
Automatically create calendar events when bookings are confirmed.

### Add SMS Notifications:
Use Twilio integration to send text confirmations.

### Add Payment Integration:
Link to Stripe or PayPal for online payments.

### Create a Dashboard:
Add a summary tab with charts showing:
- Monthly revenue
- Booking trends
- Most popular services
- Average job duration

---

## 📞 SUPPORT & NEXT STEPS

### System is Now Ready!
✓ Professional web form
✓ Automatic data collection
✓ Email notifications
✓ Time tracking system
✓ Automated invoicing

### Promote Your New Booking System:
- Add form link to your website navigation
- Include link in email signature
- Share on social media
- Add to business cards
- Create QR code for easy mobile access

### QR Code Generation:
1. Go to qr-code-generator.com
2. Choose "URL"
3. Enter your form URL
4. Download and print QR code
5. Add to business cards, flyers, vehicles

---

## 📋 QUICK REFERENCE

**Web Form URL:** [Your form URL]
**FAQ Sheet:** [Your FAQ link]
**Google Sheet:** [Your sheet link]
**Support Email:** [Your email]

**Booking Process:**
Customer submits form → Data in Bookings tab → Auto-emails sent → You confirm → Update Status → Service performed → Time tracking (door-to-door) → Weekly invoice (Friday) → Payment due in 10 days

**Important Policies:**
- **Time Tracking**: Door-to-door (from shop to shop, including travel)
- **Invoicing**: Weekly (every Friday)
- **Payment Terms**: Net 10 days from invoice date
- **Hourly Rate**: $130/hour

---

**System Built:** February 2026
**For:** IMI SERVICE LLC
**Rate:** $130/hour

Your professional booking system is ready to accept customers 24/7!
